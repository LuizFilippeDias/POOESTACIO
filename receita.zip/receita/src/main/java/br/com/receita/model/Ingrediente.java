/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.receita.model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author ldias
 */
@Entity
public class Ingrediente implements Serializable {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private long idIngrediente;
    private String nome;
    private String TipoDoPrato;
    private float QuantidadeDeMassa;
    private float TempoNoForno;
    private float TempoMexendo;
    private float QuantidadeDeAgua;
    private float QuantidadeDeTemperos;

    /**
     * @return the idIngredientes
     */
    public long getIdIngrediente() {
        return idIngrediente;
    }

    /**
     * @param idIngrediente the idIngredientes to set
     */
    public void setIdIngrediente(long idIngrediente) {
        this.idIngrediente = idIngrediente;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the TipoDoPrato
     */
    public String getTipoDoPrato() {
        return TipoDoPrato;
    }

    /**
     * @param TipoDoPrato the TipoDoPrato to set
     */
    public void setTipoDoPrato(String TipoDoPrato) {
        this.TipoDoPrato = TipoDoPrato;
    }

    /**
     * @return the QuantidadeDeMassa
     */
    public float getQuantidadeDeMassa() {
        return QuantidadeDeMassa;
    }

    /**
     * @param QuantidadeDeMassa the QuantidadeDeMassa to set
     */
    public void setQuantidadeDeMassa(float QuantidadeDeMassa) {
        this.QuantidadeDeMassa = QuantidadeDeMassa;
    }

    /**
     * @return the TempoNoForno
     */
    public float getTempoNoForno() {
        return TempoNoForno;
    }

    /**
     * @param TempoNoForno the TempoNoForno to set
     */
    public void setTempoNoForno(float TempoNoForno) {
        this.TempoNoForno = TempoNoForno;
    }

    /**
     * @return the TempoMexendo
     */
    public float getTempoMexendo() {
        return TempoMexendo;
    }

    /**
     * @param TempoMexendo the TempoMexendo to set
     */
    public void setTempoMexendo(float TempoMexendo) {
        this.TempoMexendo = TempoMexendo;
    }

    /**
     * @return the QuantidadeDeAgua
     */
    public float getQuantidadeDeAgua() {
        return QuantidadeDeAgua;
    }

    /**
     * @param QuantidadeDeAgua the QuantidadeDeAgua to set
     */
    public void setQuantidadeDeAgua(float QuantidadeDeAgua) {
        this.QuantidadeDeAgua = QuantidadeDeAgua;
    }

    /**
     * @return the QuantidadeDeTemperos
     */
    public float getQuantidadeDeTemperos() {
        return QuantidadeDeTemperos;
    }

    /**
     * @param QuantidadeDeTemperos the QuantidadeDeTemperos to set
     */
    public void setQuantidadeDeTemperos(float QuantidadeDeTemperos) {
        this.QuantidadeDeTemperos = QuantidadeDeTemperos;
    }
    
}

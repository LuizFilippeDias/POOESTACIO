package br.com.receita;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReceitaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReceitaApplication.class, args);
	}

}

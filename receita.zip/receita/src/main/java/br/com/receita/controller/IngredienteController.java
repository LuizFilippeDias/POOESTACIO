package br.com.receita.controller;


import br.com.receita.model.Ingrediente;
import br.com.receita.repository.IngredienteRepository;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class IngredienteController {

    @Autowired
    private IngredienteRepository ingredienteRepository;

    @GetMapping("/gerenciarIngredientes")
    public String listarIngredientes(Model model) {
        model.addAttribute("listaIngredientes", ingredienteRepository.findAll());
        return "gerenciar_ingredientes";
    }

    @GetMapping("/novoIngrediente")
    public String novoIngrediente(Model model) {
        model.addAttribute("ingrediente", new Ingrediente());
        return "editar_ingrediente";
    }

    @GetMapping("/editarIngrediente/{id}")
    public String editarIngrediente(@PathVariable("id") long idIngrediente, Model model) {
        Optional<Ingrediente> ingrediente = ingredienteRepository.findById(idIngrediente);
        model.addAttribute("ingrediente", ingrediente.get());
        return "editar_ingrediente";
    }

    @PostMapping("/salvarIngrediente")
    public String salvarIngrediente(Ingrediente ingrediente, BindingResult result) {
        if (result.hasErrors()) {
            return "editar_ingrediente";
        }
        ingredienteRepository.save(ingrediente);
        return "redirect:/gerenciarIngredientes";
    }

    @GetMapping("/excluirIngrediente/{id}")
    public String excluirIngrediente(@PathVariable("id") long idIngrediente) {
        ingredienteRepository.deleteById(idIngrediente);
        return "redirect:/gerenciarIngredientes";
    }
}